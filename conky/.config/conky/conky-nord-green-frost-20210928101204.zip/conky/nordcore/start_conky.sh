#!/bin/bash
sleep 10
conky -c ~/.conky/nordcore/conkyrc2core
